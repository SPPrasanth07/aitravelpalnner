import { Star, Clock, Users } from 'lucide-react'
import Card from './Card.jsx'
import Button from './Button.jsx'

export default function BusCard({ bus, onViewSeats }) {
  return (
    <Card className="p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-bold text-navy-800">{bus.operator}</h3>
          <span className="inline-block text-xs bg-sky-50 text-sky-700 px-2 py-0.5 rounded-lg mt-1 font-medium">
            {bus.type}
          </span>
        </div>
        <div className="flex items-center gap-1 text-sky-600 font-semibold text-sm">
          {bus.rating}
          <Star size={14} className="fill-sky-500 text-sky-500" />
        </div>
      </div>

      <div className="flex items-center gap-4 mt-4 text-sm">
        <div>
          <p className="font-bold text-navy-800">{bus.departure}</p>
          <p className="text-xs text-navy-400">Departure</p>
        </div>
        <div className="flex-1 flex flex-col items-center px-2">
          <span className="text-xs text-navy-400 flex items-center gap-1">
            <Clock size={12} /> {bus.duration}
          </span>
          <div className="w-full h-px bg-navy-100 my-1.5 relative">
            <span className="absolute -right-1 -top-1 w-2 h-2 rounded-full bg-sky-500" />
          </div>
        </div>
        <div className="text-right">
          <p className="font-bold text-navy-800">{bus.arrival}</p>
          <p className="text-xs text-navy-400">Arrival</p>
        </div>
      </div>

      <div className="flex items-center justify-between mt-4 pt-4 border-t border-navy-100 flex-wrap gap-3">
        <div className="flex items-center gap-4">
          <div>
            <p className="text-lg font-extrabold text-navy-800">${bus.price}</p>
            <p className="text-xs text-navy-400">starting price</p>
          </div>
          <div className="flex items-center gap-1 text-xs text-navy-400">
            <Users size={13} />
            {bus.availableSeats} seats left
          </div>
        </div>
        <Button variant="accent" size="sm" onClick={() => onViewSeats(bus)}>
          View Seats
        </Button>
      </div>
    </Card>
  )
}
