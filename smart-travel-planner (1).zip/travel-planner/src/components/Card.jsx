export default function Card({ children, className = '', as: Tag = 'div', ...props }) {
  return (
    <Tag
      className={`bg-white border border-navy-100/80 rounded-2xl shadow-card ${className}`}
      {...props}
    >
      {children}
    </Tag>
  )
}
