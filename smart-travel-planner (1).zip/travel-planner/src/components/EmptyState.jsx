import { SearchX } from 'lucide-react'

export default function EmptyState({ title = 'No results found', message = 'Try adjusting your search or filters.', icon: Icon = SearchX }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 px-6">
      <div className="w-14 h-14 rounded-full bg-navy-50 flex items-center justify-center mb-4">
        <Icon size={26} className="text-navy-400" />
      </div>
      <p className="font-semibold text-navy-800">{title}</p>
      <p className="text-sm text-navy-400 mt-1 max-w-xs">{message}</p>
    </div>
  )
}
