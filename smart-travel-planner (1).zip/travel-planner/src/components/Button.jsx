export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  className = '',
  icon: Icon,
  ...props
}) {
  const base =
    'inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-colors duration-150 focus-ring disabled:opacity-50 disabled:cursor-not-allowed'

  const variants = {
    primary: 'bg-navy-600 text-white hover:bg-navy-700',
    accent: 'bg-sky-500 text-white hover:bg-sky-600',
    outline: 'border border-navy-200 text-navy-700 bg-white hover:bg-navy-50',
    ghost: 'text-navy-600 hover:bg-navy-50',
    danger: 'bg-red-50 text-red-600 hover:bg-red-100'
  }

  const sizes = {
    sm: 'text-sm px-3 py-1.5',
    md: 'text-sm px-4 py-2.5',
    lg: 'text-base px-5 py-3'
  }

  return (
    <button className={`${base} ${variants[variant]} ${sizes[size]} ${className}`} {...props}>
      {Icon && <Icon size={16} strokeWidth={2} />}
      {children}
    </button>
  )
}
