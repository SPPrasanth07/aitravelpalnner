import { Star, MapPin, Wifi, Waves, Coffee, ParkingCircle, Dumbbell, Sparkles, PawPrint } from 'lucide-react'
import Card from './Card.jsx'
import Button from './Button.jsx'

const amenityIcons = {
  'Free Wi-Fi': Wifi,
  'Swimming pool': Waves,
  'Breakfast included': Coffee,
  Parking: ParkingCircle,
  Gym: Dumbbell,
  Spa: Sparkles,
  'Pet friendly': PawPrint
}

export default function HotelCard({ hotel, onViewDetails, onBook }) {
  return (
    <Card className="overflow-hidden flex flex-col sm:flex-row">
      <img
        src={hotel.image}
        alt={hotel.name}
        className="w-full sm:w-56 h-48 sm:h-auto object-cover shrink-0"
        loading="lazy"
      />
      <div className="p-5 flex flex-col flex-1 min-w-0">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 className="font-bold text-navy-800 truncate">{hotel.name}</h3>
            <p className="text-sm text-navy-400 flex items-center gap-1 mt-0.5">
              <MapPin size={13} /> {hotel.location}
            </p>
          </div>
          <div className="flex items-center gap-1 text-sky-600 font-semibold text-sm shrink-0">
            {hotel.reviewScore}
            <Star size={14} className="fill-sky-500 text-sky-500" />
          </div>
        </div>

        <div className="flex items-center gap-1 mt-2">
          {Array.from({ length: hotel.rating }).map((_, i) => (
            <Star key={i} size={13} className="fill-navy-600 text-navy-600" />
          ))}
          <span className="text-xs text-navy-400 ml-1">({hotel.reviewCount} reviews)</span>
        </div>

        <div className="flex flex-wrap gap-2 mt-3">
          {hotel.amenities.map((a) => {
            const Icon = amenityIcons[a]
            return (
              <span
                key={a}
                className="inline-flex items-center gap-1 text-xs bg-navy-50 text-navy-600 px-2 py-1 rounded-lg"
              >
                {Icon && <Icon size={12} />}
                {a}
              </span>
            )
          })}
        </div>

        <div className="mt-auto pt-4 flex items-end justify-between gap-3 flex-wrap">
          <div>
            <p className="text-xl font-extrabold text-navy-800">
              ${hotel.pricePerNight}
              <span className="text-xs font-medium text-navy-400"> /night</span>
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => onViewDetails(hotel)}>
              View Details
            </Button>
            <Button variant="accent" size="sm" onClick={() => onBook(hotel)}>
              Book Now
            </Button>
          </div>
        </div>
      </div>
    </Card>
  )
}
