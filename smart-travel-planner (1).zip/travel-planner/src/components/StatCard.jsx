import Card from './Card.jsx'

export default function StatCard({ label, value, icon: Icon }) {
  return (
    <Card className="p-4 flex items-center gap-3">
      {Icon && (
        <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
          <Icon size={18} />
        </div>
      )}
      <div>
        <p className="text-lg font-bold text-navy-800 leading-tight">{value}</p>
        <p className="text-xs text-navy-400">{label}</p>
      </div>
    </Card>
  )
}
