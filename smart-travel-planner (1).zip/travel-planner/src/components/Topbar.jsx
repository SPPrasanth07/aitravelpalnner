import { Menu, Bell } from 'lucide-react'

export default function Topbar({ title, subtitle, onMenuClick }) {
  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-navy-100">
      <div className="h-16 px-4 sm:px-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <button
            className="lg:hidden p-2 -ml-2 rounded-lg hover:bg-navy-50 text-navy-600 focus-ring"
            onClick={onMenuClick}
            aria-label="Open menu"
          >
            <Menu size={20} />
          </button>
          <div className="min-w-0">
            <h1 className="font-bold text-navy-800 text-base sm:text-lg truncate">{title}</h1>
            {subtitle && <p className="text-xs text-navy-400 truncate hidden sm:block">{subtitle}</p>}
          </div>
        </div>

        <div className="flex items-center gap-3 sm:gap-4 shrink-0">
          <button
            className="p-2 rounded-lg hover:bg-navy-50 text-navy-500 relative focus-ring"
            aria-label="Notifications"
          >
            <Bell size={19} />
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-sky-500 rounded-full" />
          </button>
          <div className="flex items-center gap-2.5 pl-3 border-l border-navy-100">
            <div className="w-9 h-9 rounded-full bg-navy-600 text-white flex items-center justify-center text-sm font-semibold">
              AR
            </div>
            <div className="hidden sm:block leading-tight">
              <p className="text-sm font-semibold text-navy-800">Aarav Rao</p>
              <p className="text-xs text-navy-400">Explorer tier</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
