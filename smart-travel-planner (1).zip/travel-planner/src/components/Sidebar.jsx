import { NavLink } from 'react-router-dom'
import { LayoutDashboard, BedDouble, Bus, Map, Settings, Compass, X } from 'lucide-react'

const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/hotels', label: 'Hotel Booking', icon: BedDouble },
  { to: '/buses', label: 'Bus Booking', icon: Bus },
  { to: '/map', label: 'Map View', icon: Map },
  { to: '/settings', label: 'Settings', icon: Settings }
]

export default function Sidebar({ open, onClose }) {
  return (
    <>
      {open && (
        <div className="fixed inset-0 bg-navy-900/40 z-40 lg:hidden" onClick={onClose} />
      )}
      <aside
        className={`fixed lg:sticky top-0 z-50 lg:z-0 h-screen w-64 bg-navy-700 text-white flex flex-col shrink-0
        transition-transform duration-200 ${open ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}
      >
        <div className="flex items-center justify-between px-5 h-16 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-sky-500 flex items-center justify-center">
              <Compass size={20} />
            </div>
            <span className="font-bold text-[15px] leading-tight">
              Smart Travel
              <br />
              Planner
            </span>
          </div>
          <button className="lg:hidden text-white/70 hover:text-white" onClick={onClose} aria-label="Close menu">
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
          {navItems.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors focus-ring ${
                  isActive ? 'bg-sky-500 text-white' : 'text-navy-100/80 hover:bg-white/10'
                }`
              }
            >
              <Icon size={18} />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="px-5 py-4 border-t border-white/10 text-xs text-navy-200/70">
          Smart Travel Planner &copy; 2026
          <br />
          Frontend prototype
        </div>
      </aside>
    </>
  )
}
