import { useMemo, useState } from 'react'
import { generateSeatLayout } from '../data/dummyData.js'
import Button from './Button.jsx'

export default function SeatMap({ bus, onContinue }) {
  const layout = useMemo(() => generateSeatLayout(), [bus.id])
  const [selected, setSelected] = useState([])

  const toggleSeat = (seat) => {
    if (seat.status === 'booked') return
    setSelected((prev) =>
      prev.includes(seat.number) ? prev.filter((n) => n !== seat.number) : [...prev, seat.number]
    )
  }

  const total = selected.length * bus.price

  const seatClass = (seat) => {
    if (seat.status === 'booked') return 'bg-navy-200 text-navy-400 cursor-not-allowed'
    if (selected.includes(seat.number)) return 'bg-sky-500 text-white'
    return 'bg-white border border-navy-200 text-navy-600 hover:border-sky-400'
  }

  return (
    <div>
      <div className="flex items-center gap-5 text-xs text-navy-500 mb-5">
        <span className="flex items-center gap-1.5">
          <span className="w-3.5 h-3.5 rounded bg-white border border-navy-200 inline-block" /> Available
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-3.5 h-3.5 rounded bg-sky-500 inline-block" /> Selected
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-3.5 h-3.5 rounded bg-navy-200 inline-block" /> Booked
        </span>
      </div>

      <div className="bg-navy-50 rounded-2xl p-5 max-w-xs mx-auto">
        <div className="flex justify-end mb-3 pr-1">
          <span className="text-[10px] text-navy-400 uppercase tracking-wide">Driver</span>
        </div>
        <div className="space-y-2.5">
          {layout.map((row, i) => (
            <div key={i} className="flex items-center justify-center gap-2.5">
              {row.slice(0, 2).map((seat) => (
                <button
                  key={seat.id}
                  onClick={() => toggleSeat(seat)}
                  disabled={seat.status === 'booked'}
                  className={`w-8 h-8 rounded-lg text-[11px] font-semibold flex items-center justify-center transition-colors focus-ring ${seatClass(
                    seat
                  )}`}
                >
                  {seat.number}
                </button>
              ))}
              <span className="w-4" />
              {row.slice(2, 4).map((seat) => (
                <button
                  key={seat.id}
                  onClick={() => toggleSeat(seat)}
                  disabled={seat.status === 'booked'}
                  className={`w-8 h-8 rounded-lg text-[11px] font-semibold flex items-center justify-center transition-colors focus-ring ${seatClass(
                    seat
                  )}`}
                >
                  {seat.number}
                </button>
              ))}
            </div>
          ))}
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between flex-wrap gap-3 bg-white border border-navy-100 rounded-xl p-4">
        <div>
          <p className="text-sm text-navy-500">
            Selected seats:{' '}
            <span className="font-semibold text-navy-800">
              {selected.length ? selected.sort((a, b) => a - b).join(', ') : 'None'}
            </span>
          </p>
          <p className="text-lg font-extrabold text-navy-800 mt-1">Total: ${total}</p>
        </div>
        <Button variant="accent" disabled={selected.length === 0} onClick={() => onContinue(selected, total)}>
          Continue
        </Button>
      </div>
    </div>
  )
}
