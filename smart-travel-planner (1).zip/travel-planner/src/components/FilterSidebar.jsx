import Card from './Card.jsx'

const amenityOptions = ['Free Wi-Fi', 'Swimming pool', 'Breakfast included']

export default function FilterSidebar({ filters, onChange }) {
  const toggleAmenity = (amenity) => {
    const next = filters.amenities.includes(amenity)
      ? filters.amenities.filter((a) => a !== amenity)
      : [...filters.amenities, amenity]
    onChange({ ...filters, amenities: next })
  }

  return (
    <Card className="p-5 h-fit lg:sticky lg:top-24">
      <h3 className="font-bold text-navy-800 mb-4">Filters</h3>

      <div className="mb-5">
        <div className="flex items-center justify-between mb-2">
          <label className="text-sm font-semibold text-navy-700">Price range</label>
          <span className="text-xs text-navy-400">Up to ${filters.maxPrice}</span>
        </div>
        <input
          type="range"
          min="20"
          max="250"
          step="5"
          value={filters.maxPrice}
          onChange={(e) => onChange({ ...filters, maxPrice: Number(e.target.value) })}
          className="w-full accent-sky-500"
        />
      </div>

      <div className="mb-5">
        <label className="text-sm font-semibold text-navy-700 block mb-2">Star rating</label>
        <div className="flex gap-2 flex-wrap">
          {[5, 4, 3].map((star) => (
            <button
              key={star}
              onClick={() => onChange({ ...filters, minStars: filters.minStars === star ? 0 : star })}
              className={`text-xs px-3 py-1.5 rounded-lg border focus-ring ${
                filters.minStars === star
                  ? 'bg-navy-600 text-white border-navy-600'
                  : 'border-navy-200 text-navy-600 hover:bg-navy-50'
              }`}
            >
              {star}+ stars
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="text-sm font-semibold text-navy-700 block mb-2">Amenities</label>
        <div className="space-y-2">
          {amenityOptions.map((a) => (
            <label key={a} className="flex items-center gap-2 text-sm text-navy-600 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.amenities.includes(a)}
                onChange={() => toggleAmenity(a)}
                className="accent-sky-500 w-4 h-4"
              />
              {a}
            </label>
          ))}
        </div>
      </div>
    </Card>
  )
}
