export const popularDestinations = [
  {
    id: 'dest-1',
    name: 'Santorini, Greece',
    image: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=800&q=80',
    tag: 'Island escape',
    priceFrom: 820
  },
  {
    id: 'dest-2',
    name: 'Kyoto, Japan',
    image: 'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?auto=format&fit=crop&w=800&q=80',
    tag: 'Culture & temples',
    priceFrom: 640
  },
  {
    id: 'dest-3',
    name: 'Jaipur, India',
    image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=800&q=80',
    tag: 'Heritage city',
    priceFrom: 210
  },
  {
    id: 'dest-4',
    name: 'Banff, Canada',
    image: 'https://images.unsplash.com/photo-1609825488888-3a766db05542?auto=format&fit=crop&w=800&q=80',
    tag: 'Mountains & lakes',
    priceFrom: 760
  },
  {
    id: 'dest-5',
    name: 'Bali, Indonesia',
    image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=800&q=80',
    tag: 'Beaches & rice fields',
    priceFrom: 390
  },
  {
    id: 'dest-6',
    name: 'Reykjavik, Iceland',
    image: 'https://images.unsplash.com/photo-1504829857797-ddff29c27927?auto=format&fit=crop&w=800&q=80',
    tag: 'Northern lights',
    priceFrom: 910
  }
]

export const recommendedDestinations = [
  {
    id: 'rec-1',
    name: 'Udaipur, India',
    image: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=800&q=80',
    reason: 'Because you searched Jaipur'
  },
  {
    id: 'rec-2',
    name: 'Lisbon, Portugal',
    image: 'https://images.unsplash.com/photo-1588535780747-f5571ba6362a?auto=format&fit=crop&w=800&q=80',
    reason: 'Trending with travellers like you'
  },
  {
    id: 'rec-3',
    name: 'Queenstown, New Zealand',
    image: 'https://images.unsplash.com/photo-1589196728426-eb8f085c3f65?auto=format&fit=crop&w=800&q=80',
    reason: 'Great value this season'
  },
  {
    id: 'rec-4',
    name: 'Marrakech, Morocco',
    image: 'https://images.unsplash.com/photo-1597212720158-aa5b9c0b1c22?auto=format&fit=crop&w=800&q=80',
    reason: 'Popular in your budget range'
  }
]

export const upcomingTrips = [
  {
    id: 'trip-1',
    destination: 'Bali, Indonesia',
    dateRange: '12 Dec - 19 Dec 2026',
    status: 'Confirmed',
    image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'trip-2',
    destination: 'Kyoto, Japan',
    dateRange: '03 Feb - 10 Feb 2027',
    status: 'Pending payment',
    image: 'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?auto=format&fit=crop&w=400&q=80'
  }
]

export const recentSearches = [
  { id: 'search-1', query: 'Hotels in Jaipur', date: '2 days ago' },
  { id: 'search-2', query: 'Buses from Chennai to Bengaluru', date: '4 days ago' },
  { id: 'search-3', query: 'Hotels in Goa', date: '1 week ago' }
]

export const travelStats = [
  { id: 'stat-1', label: 'Trips completed', value: '14' },
  { id: 'stat-2', label: 'Countries visited', value: '9' },
  { id: 'stat-3', label: 'Reward points', value: '2,430' },
  { id: 'stat-4', label: 'Saved places', value: '27' }
]

const amenitiesPool = ['Free Wi-Fi', 'Swimming pool', 'Breakfast included', 'Parking', 'Gym', 'Spa', 'Pet friendly']

export const hotels = [
  {
    id: 'hotel-1',
    name: 'The Navy Harbour Hotel',
    location: 'Marine Drive, Mumbai',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
    rating: 5,
    reviewScore: 4.8,
    reviewCount: 1240,
    pricePerNight: 184,
    amenities: ['Free Wi-Fi', 'Swimming pool', 'Breakfast included', 'Spa'],
    description:
      'A waterfront retreat with panoramic sea views, a rooftop infinity pool and a full-service spa, minutes from the city centre.'
  },
  {
    id: 'hotel-2',
    name: 'Sky Blue Residency',
    location: 'Koramangala, Bengaluru',
    image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=800&q=80',
    rating: 4,
    reviewScore: 4.5,
    reviewCount: 860,
    pricePerNight: 96,
    amenities: ['Free Wi-Fi', 'Breakfast included', 'Gym'],
    description: 'Modern business-friendly rooms close to the tech district, with a 24-hour gym and co-working lounge.'
  },
  {
    id: 'hotel-3',
    name: 'Palm Grove Resort',
    location: 'Calangute, Goa',
    image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=800&q=80',
    rating: 5,
    reviewScore: 4.9,
    reviewCount: 2010,
    pricePerNight: 221,
    amenities: ['Free Wi-Fi', 'Swimming pool', 'Breakfast included', 'Pet friendly', 'Parking'],
    description: 'Beachfront villas surrounded by palm groves, with a private stretch of sand and sunset cabana service.'
  },
  {
    id: 'hotel-4',
    name: 'Heritage Haveli Inn',
    location: 'Pink City, Jaipur',
    image: 'https://images.unsplash.com/photo-1544124499-58912cbddaad?auto=format&fit=crop&w=800&q=80',
    rating: 4,
    reviewScore: 4.3,
    reviewCount: 540,
    pricePerNight: 68,
    amenities: ['Free Wi-Fi', 'Breakfast included', 'Parking'],
    description: 'A restored 19th-century haveli with courtyard dining and handcrafted interiors in the old city.'
  },
  {
    id: 'hotel-5',
    name: 'Lakeside Serenity Suites',
    location: 'Lake Pichola, Udaipur',
    image: 'https://images.unsplash.com/photo-1455587734955-081b22074882?auto=format&fit=crop&w=800&q=80',
    rating: 5,
    reviewScore: 4.7,
    reviewCount: 980,
    pricePerNight: 158,
    amenities: ['Free Wi-Fi', 'Swimming pool', 'Spa', 'Breakfast included'],
    description: 'Lakefront suites with private balconies looking out over the City Palace and the water.'
  },
  {
    id: 'hotel-6',
    name: 'Urban Nest Hostel',
    location: 'Indiranagar, Bengaluru',
    image: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80',
    rating: 3,
    reviewScore: 4.1,
    reviewCount: 410,
    pricePerNight: 32,
    amenities: ['Free Wi-Fi', 'Parking'],
    description: 'Budget-friendly pods and shared lounges in the heart of the city\u2019s café district.'
  }
].map((h) => ({ ...h, amenities: h.amenities.filter((a) => amenitiesPool.includes(a)) }))

export const buses = [
  {
    id: 'bus-1',
    operator: 'BlueLine Travels',
    type: 'AC Sleeper',
    departure: '21:30',
    arrival: '06:00',
    duration: '8h 30m',
    price: 24,
    availableSeats: 18,
    rating: 4.5
  },
  {
    id: 'bus-2',
    operator: 'Navy Express Coaches',
    type: 'Non-AC Sleeper',
    departure: '22:15',
    arrival: '07:10',
    duration: '8h 55m',
    price: 15,
    availableSeats: 9,
    rating: 3.9
  },
  {
    id: 'bus-3',
    operator: 'Horizon Roadways',
    type: 'AC Seater',
    departure: '07:00',
    arrival: '13:40',
    duration: '6h 40m',
    price: 18,
    availableSeats: 27,
    rating: 4.2
  },
  {
    id: 'bus-4',
    operator: 'Coastal Comfort Travels',
    type: 'AC Sleeper',
    departure: '23:00',
    arrival: '07:45',
    duration: '8h 45m',
    price: 28,
    availableSeats: 4,
    rating: 4.7
  },
  {
    id: 'bus-5',
    operator: 'Summit Line',
    type: 'AC Seater',
    departure: '14:30',
    arrival: '20:50',
    duration: '6h 20m',
    price: 17,
    availableSeats: 31,
    rating: 4.0
  }
]

// Seat layout: 'A' available, 'B' booked. Selected handled in component state.
export const generateSeatLayout = () => {
  const rows = 9
  const seatsPerRow = 4
  const layout = []
  let seatNumber = 1
  for (let r = 0; r < rows; r++) {
    const row = []
    for (let s = 0; s < seatsPerRow; s++) {
      const isBooked = Math.random() < 0.28
      row.push({
        id: `S${seatNumber}`,
        number: seatNumber,
        status: isBooked ? 'booked' : 'available'
      })
      seatNumber++
    }
    layout.push(row)
  }
  return layout
}

export const mapDestinations = [
  {
    id: 'map-1',
    name: 'Eiffel Tower',
    category: 'Tourist place',
    position: { top: '32%', left: '46%' },
    description: 'Iconic iron landmark in the heart of Paris, best visited at sunset.'
  },
  {
    id: 'map-2',
    name: 'The Navy Harbour Hotel',
    category: 'Hotel',
    position: { top: '48%', left: '58%' },
    description: '5-star waterfront hotel with rooftop pool and spa access.'
  },
  {
    id: 'map-3',
    name: 'Central Bus Terminal',
    category: 'Bus terminal',
    position: { top: '63%', left: '34%' },
    description: 'Main interstate terminal with 24-hour ticket counters.'
  },
  {
    id: 'map-4',
    name: 'Riverside Market',
    category: 'Tourist place',
    position: { top: '22%', left: '66%' },
    description: 'Open-air market with local crafts, food stalls and live music.'
  },
  {
    id: 'map-5',
    name: 'Sky Blue Residency',
    category: 'Hotel',
    position: { top: '72%', left: '60%' },
    description: 'Business-friendly stay near the tech district, 10 minutes from downtown.'
  },
  {
    id: 'map-6',
    name: 'Old Town Square',
    category: 'Tourist place',
    position: { top: '54%', left: '22%' },
    description: 'Historic square surrounded by cafes and cobblestone streets.'
  }
]

export const nearbyAttractions = [
  { id: 'near-1', name: 'Botanical Gardens', distance: '1.2 km' },
  { id: 'near-2', name: 'Harbourfront Walk', distance: '2.0 km' },
  { id: 'near-3', name: 'Art & History Museum', distance: '2.6 km' },
  { id: 'near-4', name: 'Sunset Viewpoint', distance: '3.4 km' }
]
