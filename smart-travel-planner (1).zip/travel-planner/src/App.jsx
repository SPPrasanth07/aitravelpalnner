import { useState } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import Sidebar from './components/Sidebar.jsx'
import Topbar from './components/Topbar.jsx'
import Dashboard from './pages/Dashboard.jsx'
import HotelBooking from './pages/HotelBooking.jsx'
import BusBooking from './pages/BusBooking.jsx'
import MapView from './pages/MapView.jsx'
import Settings from './pages/Settings.jsx'

const pageMeta = {
  '/': { title: 'Dashboard', subtitle: 'Your travel overview' },
  '/hotels': { title: 'Hotel Booking', subtitle: 'Find and book your stay' },
  '/buses': { title: 'Bus Booking', subtitle: 'Search interstate routes' },
  '/map': { title: 'Map View', subtitle: 'Explore nearby places' },
  '/settings': { title: 'Settings', subtitle: 'Manage your account' }
}

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const location = useLocation()
  const meta = pageMeta[location.pathname] || pageMeta['/']

  return (
    <div className="flex min-h-screen bg-[#f6f7f9]">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 min-w-0 flex flex-col">
        <Topbar title={meta.title} subtitle={meta.subtitle} onMenuClick={() => setSidebarOpen(true)} />

        <main className="flex-1 p-4 sm:p-6 max-w-[1400px] w-full mx-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/hotels" element={<HotelBooking />} />
            <Route path="/buses" element={<BusBooking />} />
            <Route path="/map" element={<MapView />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>
      </div>
    </div>
  )
}
