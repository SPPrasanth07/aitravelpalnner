import { useMemo, useState } from 'react'
import { ArrowLeftRight, Calendar, Users, MapPin, CheckCircle2 } from 'lucide-react'
import Card from '../components/Card.jsx'
import Button from '../components/Button.jsx'
import BusCard from '../components/BusCard.jsx'
import SeatMap from '../components/SeatMap.jsx'
import Modal from '../components/Modal.jsx'
import EmptyState from '../components/EmptyState.jsx'
import { buses } from '../data/dummyData.js'

export default function BusBooking() {
  const [fromCity, setFromCity] = useState('Chennai')
  const [toCity, setToCity] = useState('Bengaluru')
  const [date, setDate] = useState('')
  const [passengers, setPassengers] = useState(1)
  const [searched, setSearched] = useState(true)
  const [typeFilter, setTypeFilter] = useState('All')
  const [seatBus, setSeatBus] = useState(null)
  const [confirmation, setConfirmation] = useState(null)

  const results = useMemo(() => {
    if (!searched) return []
    return buses.filter((b) => typeFilter === 'All' || b.type === typeFilter)
  }, [searched, typeFilter])

  const swapCities = () => {
    setFromCity(toCity)
    setToCity(fromCity)
  }

  const handleSearch = (e) => {
    e.preventDefault()
    setSearched(true)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold text-navy-800">Bus Booking</h2>
        <p className="text-navy-400 text-sm mt-1">Search interstate routes and pick your seats.</p>
      </div>

      <Card className="p-5 sm:p-6">
        <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr_1fr_1fr_auto] gap-3 items-center">
          <div className="relative">
            <MapPin size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <input
              value={fromCity}
              onChange={(e) => setFromCity(e.target.value)}
              placeholder="From city"
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
            />
          </div>
          <button
            type="button"
            onClick={swapCities}
            className="justify-self-center p-2.5 rounded-full border border-navy-200 text-navy-500 hover:bg-navy-50 focus-ring"
            aria-label="Swap cities"
          >
            <ArrowLeftRight size={16} />
          </button>
          <div className="relative">
            <MapPin size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <input
              value={toCity}
              onChange={(e) => setToCity(e.target.value)}
              placeholder="To city"
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
            />
          </div>
          <div className="relative">
            <Calendar size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
            />
          </div>
          <div className="relative">
            <Users size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <select
              value={passengers}
              onChange={(e) => setPassengers(Number(e.target.value))}
              className="w-full pl-10 pr-2 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring bg-white appearance-none"
            >
              {[1, 2, 3, 4].map((n) => (
                <option key={n} value={n}>
                  {n} passenger{n > 1 ? 's' : ''}
                </option>
              ))}
            </select>
          </div>
          <Button type="submit" variant="accent" className="whitespace-nowrap">
            Search Buses
          </Button>
        </form>
      </Card>

      {searched && (
        <>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <p className="text-sm text-navy-500">
              <span className="font-semibold text-navy-800">{results.length}</span> buses from{' '}
              <span className="font-semibold text-navy-800">{fromCity}</span> to{' '}
              <span className="font-semibold text-navy-800">{toCity}</span>
            </p>
            <div className="flex gap-2 flex-wrap">
              {['All', 'AC Sleeper', 'Non-AC Sleeper', 'AC Seater'].map((t) => (
                <button
                  key={t}
                  onClick={() => setTypeFilter(t)}
                  className={`text-xs px-3 py-1.5 rounded-lg border focus-ring ${
                    typeFilter === t
                      ? 'bg-navy-600 text-white border-navy-600'
                      : 'border-navy-200 text-navy-600 hover:bg-navy-50'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {results.length === 0 ? (
            <Card>
              <EmptyState title="No buses on this route" message="Try a different bus type or travel date." />
            </Card>
          ) : (
            <div className="space-y-4">
              {results.map((b) => (
                <BusCard key={b.id} bus={b} onViewSeats={setSeatBus} />
              ))}
            </div>
          )}
        </>
      )}

      <Modal open={!!seatBus} onClose={() => setSeatBus(null)} title={seatBus ? `Select seats \u00b7 ${seatBus.operator}` : ''}>
        {seatBus && (
          <SeatMap
            bus={seatBus}
            onContinue={(seats, total) => {
              setConfirmation({ bus: seatBus, seats, total })
              setSeatBus(null)
            }}
          />
        )}
      </Modal>

      <Modal open={!!confirmation} onClose={() => setConfirmation(null)} title="Review your ticket">
        {confirmation && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 text-sky-600">
              <CheckCircle2 size={22} />
              <p className="font-semibold text-navy-800">Seats reserved for this demo booking</p>
            </div>
            <div className="bg-navy-50 rounded-xl p-4 text-sm space-y-1.5">
              <p className="flex justify-between">
                <span className="text-navy-400">Operator</span>
                <span className="font-medium text-navy-800">{confirmation.bus.operator}</span>
              </p>
              <p className="flex justify-between">
                <span className="text-navy-400">Route</span>
                <span className="font-medium text-navy-800">
                  {fromCity} &rarr; {toCity}
                </span>
              </p>
              <p className="flex justify-between">
                <span className="text-navy-400">Seats</span>
                <span className="font-medium text-navy-800">{confirmation.seats.join(', ')}</span>
              </p>
              <p className="flex justify-between">
                <span className="text-navy-400">Total</span>
                <span className="font-bold text-navy-800">${confirmation.total}</span>
              </p>
            </div>
            <Button variant="primary" className="w-full" onClick={() => setConfirmation(null)}>
              Book Ticket
            </Button>
          </div>
        )}
      </Modal>
    </div>
  )
}
