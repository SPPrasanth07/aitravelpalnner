import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Search,
  Calendar,
  Users,
  BedDouble,
  Bus,
  Map,
  TrendingUp,
  Award,
  Globe2,
  Bookmark,
  Clock
} from 'lucide-react'
import Card from '../components/Card.jsx'
import Button from '../components/Button.jsx'
import StatCard from '../components/StatCard.jsx'
import {
  popularDestinations,
  recommendedDestinations,
  upcomingTrips,
  recentSearches,
  travelStats
} from '../data/dummyData.js'

const quickActions = [
  { label: 'Book a Hotel', icon: BedDouble, to: '/hotels', desc: 'Find your next stay' },
  { label: 'Book a Bus', icon: Bus, to: '/buses', desc: 'Travel between cities' },
  { label: 'Explore Map', icon: Map, to: '/map', desc: 'Discover nearby places' }
]

const statIcons = [TrendingUp, Globe2, Award, Bookmark]

export default function Dashboard() {
  const navigate = useNavigate()
  const [destination, setDestination] = useState('')
  const [date, setDate] = useState('')
  const [travellers, setTravellers] = useState(2)

  const handleSearch = (e) => {
    e.preventDefault()
    navigate('/hotels', { state: { destination } })
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold text-navy-800">Explore Your Next Adventure</h2>
        <p className="text-navy-400 text-sm mt-1">Plan, book and track every part of your trip in one place.</p>
      </div>

      <Card className="p-5 sm:p-6">
        <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-[1.4fr_1fr_0.8fr_auto] gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <input
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="Search destination"
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
            />
          </div>
          <div className="relative">
            <Calendar size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
            />
          </div>
          <div className="relative">
            <Users size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <select
              value={travellers}
              onChange={(e) => setTravellers(Number(e.target.value))}
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400 appearance-none bg-white"
            >
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <option key={n} value={n}>
                  {n} traveller{n > 1 ? 's' : ''}
                </option>
              ))}
            </select>
          </div>
          <Button type="submit" variant="accent" className="whitespace-nowrap">
            Search
          </Button>
        </form>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {quickActions.map(({ label, icon: Icon, to, desc }) => (
          <Card
            key={label}
            as="button"
            onClick={() => navigate(to)}
            className="p-5 text-left hover:shadow-lg hover:-translate-y-0.5 transition-all duration-150 focus-ring"
          >
            <div className="w-11 h-11 rounded-xl bg-navy-600 text-white flex items-center justify-center mb-3">
              <Icon size={20} />
            </div>
            <p className="font-bold text-navy-800">{label}</p>
            <p className="text-xs text-navy-400 mt-0.5">{desc}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {travelStats.map((s, i) => (
          <StatCard key={s.id} label={s.label} value={s.value} icon={statIcons[i]} />
        ))}
      </div>

      <section>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-navy-800">Popular destinations</h3>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-2 -mx-1 px-1">
          {popularDestinations.map((d) => (
            <Card key={d.id} className="min-w-[220px] overflow-hidden shrink-0">
              <img src={d.image} alt={d.name} className="w-full h-36 object-cover" loading="lazy" />
              <div className="p-3">
                <p className="font-semibold text-navy-800 text-sm truncate">{d.name}</p>
                <p className="text-xs text-navy-400">{d.tag}</p>
                <p className="text-sm font-bold text-sky-600 mt-1">From ${d.priceFrom}</p>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section>
          <h3 className="font-bold text-navy-800 mb-3">Upcoming trips</h3>
          <div className="space-y-3">
            {upcomingTrips.map((t) => (
              <Card key={t.id} className="p-3 flex items-center gap-3">
                <img src={t.image} alt={t.destination} className="w-16 h-16 rounded-xl object-cover shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-navy-800 text-sm truncate">{t.destination}</p>
                  <p className="text-xs text-navy-400">{t.dateRange}</p>
                </div>
                <span
                  className={`text-xs font-medium px-2.5 py-1 rounded-lg shrink-0 ${
                    t.status === 'Confirmed' ? 'bg-sky-50 text-sky-700' : 'bg-amber-50 text-amber-700'
                  }`}
                >
                  {t.status}
                </span>
              </Card>
            ))}
          </div>
        </section>

        <section>
          <h3 className="font-bold text-navy-800 mb-3">Recent searches</h3>
          <Card className="divide-y divide-navy-100">
            {recentSearches.map((s) => (
              <div key={s.id} className="flex items-center gap-3 p-3.5">
                <div className="w-8 h-8 rounded-lg bg-navy-50 flex items-center justify-center text-navy-500 shrink-0">
                  <Clock size={14} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-navy-700 truncate">{s.query}</p>
                </div>
                <span className="text-xs text-navy-400 shrink-0">{s.date}</span>
              </div>
            ))}
          </Card>
        </section>
      </div>

      <section>
        <h3 className="font-bold text-navy-800 mb-3">Recommended for you</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {recommendedDestinations.map((d) => (
            <Card key={d.id} className="overflow-hidden">
              <img src={d.image} alt={d.name} className="w-full h-28 object-cover" loading="lazy" />
              <div className="p-3">
                <p className="font-semibold text-navy-800 text-sm truncate">{d.name}</p>
                <p className="text-xs text-navy-400 mt-0.5 truncate">{d.reason}</p>
              </div>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}
