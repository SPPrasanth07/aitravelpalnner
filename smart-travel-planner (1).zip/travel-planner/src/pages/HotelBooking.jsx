import { useMemo, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { Search, Calendar, Users, BedDouble, MapPin, Star } from 'lucide-react'
import Card from '../components/Card.jsx'
import Button from '../components/Button.jsx'
import HotelCard from '../components/HotelCard.jsx'
import FilterSidebar from '../components/FilterSidebar.jsx'
import Modal from '../components/Modal.jsx'
import EmptyState from '../components/EmptyState.jsx'
import { hotels } from '../data/dummyData.js'

export default function HotelBooking() {
  const location = useLocation()
  const [destination, setDestination] = useState(location.state?.destination || '')
  const [checkIn, setCheckIn] = useState('')
  const [checkOut, setCheckOut] = useState('')
  const [guests, setGuests] = useState(2)
  const [rooms, setRooms] = useState(1)
  const [query, setQuery] = useState(location.state?.destination || '')
  const [sortBy, setSortBy] = useState('recommended')
  const [selectedHotel, setSelectedHotel] = useState(null)
  const [bookedHotel, setBookedHotel] = useState(null)
  const [filters, setFilters] = useState({ maxPrice: 250, minStars: 0, amenities: [] })

  const results = useMemo(() => {
    let list = hotels.filter((h) => {
      const matchesQuery =
        !query.trim() ||
        h.name.toLowerCase().includes(query.toLowerCase()) ||
        h.location.toLowerCase().includes(query.toLowerCase())
      const matchesPrice = h.pricePerNight <= filters.maxPrice
      const matchesStars = filters.minStars === 0 || h.rating >= filters.minStars
      const matchesAmenities = filters.amenities.every((a) => h.amenities.includes(a))
      return matchesQuery && matchesPrice && matchesStars && matchesAmenities
    })

    if (sortBy === 'price-low') list = [...list].sort((a, b) => a.pricePerNight - b.pricePerNight)
    if (sortBy === 'rating-high') list = [...list].sort((a, b) => b.reviewScore - a.reviewScore)

    return list
  }, [query, filters, sortBy])

  const handleSearch = (e) => {
    e.preventDefault()
    setQuery(destination)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold text-navy-800">Hotel Booking</h2>
        <p className="text-navy-400 text-sm mt-1">Compare stays and book the right room for your trip.</p>
      </div>

      <Card className="p-5 sm:p-6">
        <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-[1.4fr_1fr_1fr_1fr_auto] gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <input
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="Destination"
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
            />
          </div>
          <div className="relative">
            <Calendar size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <input
              type="date"
              value={checkIn}
              onChange={(e) => setCheckIn(e.target.value)}
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
              placeholder="Check-in"
            />
          </div>
          <div className="relative">
            <Calendar size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
            <input
              type="date"
              value={checkOut}
              onChange={(e) => setCheckOut(e.target.value)}
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
              placeholder="Check-out"
            />
          </div>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Users size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" />
              <select
                value={guests}
                onChange={(e) => setGuests(Number(e.target.value))}
                className="w-full pl-8 pr-2 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring bg-white appearance-none"
              >
                {[1, 2, 3, 4].map((n) => (
                  <option key={n} value={n}>
                    {n} guest{n > 1 ? 's' : ''}
                  </option>
                ))}
              </select>
            </div>
            <div className="relative flex-1">
              <BedDouble size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" />
              <select
                value={rooms}
                onChange={(e) => setRooms(Number(e.target.value))}
                className="w-full pl-8 pr-2 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring bg-white appearance-none"
              >
                {[1, 2, 3].map((n) => (
                  <option key={n} value={n}>
                    {n} room{n > 1 ? 's' : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <Button type="submit" variant="accent" className="whitespace-nowrap">
            Search Hotels
          </Button>
        </form>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-6">
        <FilterSidebar filters={filters} onChange={setFilters} />

        <div>
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
            <p className="text-sm text-navy-500">
              <span className="font-semibold text-navy-800">{results.length}</span> hotels found
            </p>
            <div className="flex items-center gap-2">
              <label className="text-xs text-navy-400">Sort by</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="text-sm border border-navy-200 rounded-lg px-2.5 py-1.5 focus-ring bg-white"
              >
                <option value="recommended">Recommended</option>
                <option value="price-low">Lowest price</option>
                <option value="rating-high">Highest rating</option>
              </select>
            </div>
          </div>

          {results.length === 0 ? (
            <Card>
              <EmptyState
                title="No hotels match your filters"
                message="Try increasing your price range or clearing an amenity filter."
              />
            </Card>
          ) : (
            <div className="space-y-4">
              {results.map((h) => (
                <HotelCard key={h.id} hotel={h} onViewDetails={setSelectedHotel} onBook={setBookedHotel} />
              ))}
            </div>
          )}
        </div>
      </div>

      <Modal open={!!selectedHotel} onClose={() => setSelectedHotel(null)} title={selectedHotel?.name}>
        {selectedHotel && (
          <div className="space-y-4">
            <img src={selectedHotel.image} alt={selectedHotel.name} className="w-full h-56 object-cover rounded-xl" />
            <p className="text-sm text-navy-500 flex items-center gap-1">
              <MapPin size={14} /> {selectedHotel.location}
            </p>
            <div className="flex items-center gap-2">
              {Array.from({ length: selectedHotel.rating }).map((_, i) => (
                <Star key={i} size={14} className="fill-navy-600 text-navy-600" />
              ))}
              <span className="text-sm text-navy-500">
                {selectedHotel.reviewScore} ({selectedHotel.reviewCount} reviews)
              </span>
            </div>
            <p className="text-sm text-navy-600">{selectedHotel.description}</p>
            <div className="flex flex-wrap gap-2">
              {selectedHotel.amenities.map((a) => (
                <span key={a} className="text-xs bg-navy-50 text-navy-600 px-2.5 py-1 rounded-lg">
                  {a}
                </span>
              ))}
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-navy-100">
              <p className="text-xl font-extrabold text-navy-800">
                ${selectedHotel.pricePerNight}
                <span className="text-xs font-medium text-navy-400"> /night</span>
              </p>
              <Button
                variant="accent"
                onClick={() => {
                  setBookedHotel(selectedHotel)
                  setSelectedHotel(null)
                }}
              >
                Book Now
              </Button>
            </div>
          </div>
        )}
      </Modal>

      <Modal open={!!bookedHotel} onClose={() => setBookedHotel(null)} title="Booking confirmed">
        {bookedHotel && (
          <div className="text-center py-4">
            <div className="w-14 h-14 rounded-full bg-sky-50 text-sky-600 flex items-center justify-center mx-auto mb-4">
              <BedDouble size={24} />
            </div>
            <p className="font-semibold text-navy-800">{bookedHotel.name}</p>
            <p className="text-sm text-navy-400 mt-1">
              {rooms} room{rooms > 1 ? 's' : ''} &middot; {guests} guest{guests > 1 ? 's' : ''}
            </p>
            <p className="text-sm text-navy-400 mt-1">This is a demo booking with no real payment involved.</p>
            <Button variant="primary" className="mt-5" onClick={() => setBookedHotel(null)}>
              Done
            </Button>
          </div>
        )}
      </Modal>
    </div>
  )
}
