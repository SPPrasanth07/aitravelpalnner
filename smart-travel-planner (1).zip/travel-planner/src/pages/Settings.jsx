import { useState } from 'react'
import { User, Bell, Lock, Globe } from 'lucide-react'
import Card from '../components/Card.jsx'
import Button from '../components/Button.jsx'

const sections = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'security', label: 'Security', icon: Lock },
  { id: 'preferences', label: 'Preferences', icon: Globe }
]

export default function Settings() {
  const [active, setActive] = useState('profile')
  const [name, setName] = useState('Aarav Rao')
  const [email, setEmail] = useState('aarav.rao@example.com')
  const [notifEmail, setNotifEmail] = useState(true)
  const [notifPush, setNotifPush] = useState(false)
  const [currency, setCurrency] = useState('USD')
  const [saved, setSaved] = useState(false)

  const handleSave = (e) => {
    e.preventDefault()
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold text-navy-800">Settings</h2>
        <p className="text-navy-400 text-sm mt-1">Manage your profile, notifications and preferences.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-6">
        <Card className="p-3 h-fit">
          <nav className="space-y-1">
            {sections.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActive(id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium focus-ring transition-colors ${
                  active === id ? 'bg-navy-600 text-white' : 'text-navy-600 hover:bg-navy-50'
                }`}
              >
                <Icon size={16} />
                {label}
              </button>
            ))}
          </nav>
        </Card>

        <Card className="p-6">
          <form onSubmit={handleSave} className="space-y-5 max-w-md">
            {active === 'profile' && (
              <>
                <div>
                  <label className="text-sm font-semibold text-navy-700 block mb-1.5">Full name</label>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
                  />
                </div>
                <div>
                  <label className="text-sm font-semibold text-navy-700 block mb-1.5">Email address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
                  />
                </div>
              </>
            )}

            {active === 'notifications' && (
              <>
                <label className="flex items-center justify-between text-sm text-navy-700">
                  Email notifications
                  <input
                    type="checkbox"
                    checked={notifEmail}
                    onChange={(e) => setNotifEmail(e.target.checked)}
                    className="accent-sky-500 w-4 h-4"
                  />
                </label>
                <label className="flex items-center justify-between text-sm text-navy-700">
                  Push notifications
                  <input
                    type="checkbox"
                    checked={notifPush}
                    onChange={(e) => setNotifPush(e.target.checked)}
                    className="accent-sky-500 w-4 h-4"
                  />
                </label>
              </>
            )}

            {active === 'security' && (
              <div>
                <label className="text-sm font-semibold text-navy-700 block mb-1.5">New password</label>
                <input
                  type="password"
                  placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring focus:border-sky-400"
                />
              </div>
            )}

            {active === 'preferences' && (
              <div>
                <label className="text-sm font-semibold text-navy-700 block mb-1.5">Preferred currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-navy-200 text-sm focus-ring bg-white appearance-none"
                >
                  <option>USD</option>
                  <option>EUR</option>
                  <option>INR</option>
                  <option>GBP</option>
                </select>
              </div>
            )}

            <div className="flex items-center gap-3 pt-2">
              <Button type="submit" variant="accent">
                Save changes
              </Button>
              {saved && <span className="text-sm text-sky-600 font-medium">Saved</span>}
            </div>
          </form>
        </Card>
      </div>
    </div>
  )
}
