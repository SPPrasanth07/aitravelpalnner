import { useState } from 'react'
import { Search, Plus, Minus, Navigation, Hotel, Bus, Landmark, Info } from 'lucide-react'
import Card from '../components/Card.jsx'
import Button from '../components/Button.jsx'
import { mapDestinations, nearbyAttractions } from '../data/dummyData.js'

const categoryIcon = {
  'Tourist place': Landmark,
  Hotel: Hotel,
  'Bus terminal': Bus
}

const categoryColor = {
  'Tourist place': 'bg-sky-500',
  Hotel: 'bg-navy-600',
  'Bus terminal': 'bg-amber-500'
}

export default function MapView() {
  const [search, setSearch] = useState('')
  const [zoom, setZoom] = useState(1)
  const [active, setActive] = useState(mapDestinations[0])

  const filtered = mapDestinations.filter((d) => d.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold text-navy-800">Map View</h2>
        <p className="text-navy-400 text-sm mt-1">Explore hotels, attractions and bus terminals near your trip.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
        <Card className="relative overflow-hidden h-[460px] sm:h-[520px]">
          <div className="absolute top-4 left-4 right-4 z-10">
            <div className="relative max-w-sm">
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-navy-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search a location"
                className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-navy-200 bg-white/95 backdrop-blur text-sm shadow-card focus-ring focus:border-sky-400"
              />
            </div>
          </div>

          <div className="absolute bottom-4 right-4 z-10 flex flex-col bg-white rounded-xl shadow-card overflow-hidden">
            <button
              className="p-2.5 hover:bg-navy-50 text-navy-600 border-b border-navy-100 focus-ring"
              onClick={() => setZoom((z) => Math.min(2, z + 0.1))}
              aria-label="Zoom in"
            >
              <Plus size={16} />
            </button>
            <button
              className="p-2.5 hover:bg-navy-50 text-navy-600 focus-ring"
              onClick={() => setZoom((z) => Math.max(0.7, z - 0.1))}
              aria-label="Zoom out"
            >
              <Minus size={16} />
            </button>
          </div>

          <div
            className="absolute inset-0 transition-transform duration-200"
            style={{
              transform: `scale(${zoom})`,
              backgroundColor: '#dbe7f3',
              backgroundImage:
                'linear-gradient(#c7d9ec 1px, transparent 1px), linear-gradient(90deg, #c7d9ec 1px, transparent 1px)',
              backgroundSize: '36px 36px'
            }}
          >
            {filtered.map((d) => {
              const Icon = categoryIcon[d.category]
              const isActive = active?.id === d.id
              return (
                <button
                  key={d.id}
                  onClick={() => setActive(d)}
                  style={{ top: d.position.top, left: d.position.left }}
                  className={`absolute -translate-x-1/2 -translate-y-full flex flex-col items-center focus-ring`}
                >
                  <div
                    className={`w-8 h-8 rounded-full ${categoryColor[d.category]} text-white flex items-center justify-center shadow-md border-2 ${
                      isActive ? 'border-white scale-110' : 'border-white/70'
                    } transition-transform`}
                  >
                    <Icon size={15} />
                  </div>
                  <span className="w-2 h-2 bg-inherit rotate-45 -mt-1 shadow-sm" />
                </button>
              )
            })}
          </div>

          <div className="absolute bottom-4 left-4 z-10 bg-white/95 backdrop-blur rounded-lg px-3 py-2 flex items-center gap-1.5 text-xs text-navy-400 max-w-[220px]">
            <Info size={13} className="shrink-0" />
            Illustrative placeholder map &mdash; ready for Leaflet/OpenStreetMap integration.
          </div>
        </Card>

        <div className="space-y-4">
          {active && (
            <Card className="p-4">
              <div className="flex items-center gap-2 mb-1.5">
                <span className={`w-7 h-7 rounded-lg ${categoryColor[active.category]} text-white flex items-center justify-center shrink-0`}>
                  {(() => {
                    const Icon = categoryIcon[active.category]
                    return <Icon size={14} />
                  })()}
                </span>
                <span className="text-xs font-medium text-navy-400">{active.category}</span>
              </div>
              <h3 className="font-bold text-navy-800">{active.name}</h3>
              <p className="text-sm text-navy-500 mt-1">{active.description}</p>
              <Button variant="accent" size="sm" className="mt-3 w-full" icon={Navigation}>
                Directions
              </Button>
            </Card>
          )}

          <Card className="p-4">
            <h3 className="font-bold text-navy-800 mb-3 text-sm">Nearby attractions</h3>
            <div className="space-y-2.5">
              {nearbyAttractions.map((a) => (
                <div key={a.id} className="flex items-center justify-between text-sm">
                  <span className="text-navy-600">{a.name}</span>
                  <span className="text-xs text-navy-400">{a.distance}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
