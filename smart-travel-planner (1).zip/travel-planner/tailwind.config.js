/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#eef2f8',
          100: '#d7e1ef',
          200: '#b0c3df',
          300: '#89a5cf',
          400: '#4d71a8',
          500: '#1f3f73',
          600: '#17305a',
          700: '#112442',
          800: '#0c1a30',
          900: '#07111f'
        },
        sky: {
          50: '#eef9ff',
          100: '#d9f1ff',
          200: '#b3e3ff',
          300: '#7ecfff',
          400: '#44b6f7',
          500: '#1f9ce8',
          600: '#147cc2',
          700: '#10619a',
          800: '#0f4e79',
          900: '#0c3c5e'
        }
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif']
      },
      boxShadow: {
        card: '0 1px 2px rgba(17, 36, 66, 0.06), 0 4px 16px rgba(17, 36, 66, 0.06)'
      }
    }
  },
  plugins: []
}
