# Smart Travel Planner — Frontend Prototype

A React + Vite + Tailwind CSS frontend UI for an AI-powered travel planner. Frontend only — no backend, database, APIs, or authentication. All data is realistic dummy data defined in `src/data/dummyData.js`.

## Pages

1. **Dashboard** (`/`) — welcome banner, search bar, quick actions, popular destinations, upcoming trips, recent searches, recommended destinations, travel stats.
2. **Hotel Booking** (`/hotels`) — search form, filter sidebar (price, stars, amenities), sortable hotel list, details modal, booking confirmation modal.
3. **Bus Booking** (`/buses`) — from/to search with swap button, bus type filter, interactive seat selection with live pricing, booking confirmation modal.
4. **Map View** (`/map`) — placeholder map with destination/hotel/bus-terminal markers, zoom controls, location info panel, nearby attractions list. Clearly labeled as an illustrative placeholder, ready to swap in Leaflet + OpenStreetMap.
5. **Settings** (`/settings`) — profile, notifications, security and preference sections (bonus page wired into the sidebar).

## Getting started

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

To build a production bundle:

```bash
npm run build
npm run preview
```

## Tech stack

- React 18 + Vite
- React Router DOM (client-side routing across the 5 pages)
- Tailwind CSS (navy / sky-blue theme, configured in `tailwind.config.js`)
- Lucide React icons

## Project structure

```
src/
  components/   # Sidebar, Topbar, Card, Button, Modal, HotelCard, BusCard, SeatMap, FilterSidebar, EmptyState, StatCard
  pages/        # Dashboard, HotelBooking, BusBooking, MapView, Settings
  data/         # dummyData.js — all mock hotels, buses, destinations, trips, map pins
```

## Notes

- All interactions (search, filters, sorting, seat selection, modals) are wired to local component state — no network calls.
- The map is an intentional placeholder (CSS grid + positioned markers), not a real geographic map, so it's never mistaken for live map data.
